
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'niteshmahawar',
  applicationName: 'clientapp',
  appUid: 'f4yrgxSmHcMng1nvSn',
  orgUid: '094200bb-38b0-43c5-a104-16829e6dfd1e',
  deploymentUid: 'ebbd54ff-4698-41a0-a5ce-e08b8b1e9042',
  serviceName: 'client',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'client-dev-app-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}