const express = require('express');
const connection = require("../connector");

const routes = express.Router({
    mergeParams: true
});

routes.get('/faccounts',(req, res) =>{
    res.status(200).json({'b':'first get'});
})

routes.get('/saccounts',(req, res) =>{
    res.status(200).json({'b':'second get'});
})

module.exports = {
    routes,
};